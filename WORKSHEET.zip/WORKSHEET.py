#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#Q11Write a python program to find the factorial of a number


# In[1]:


num = int(input("Enter a number: "))    
factorial = 1    
if num < 0:    
   print(" Factorial does not exist for negative numbers")    
elif num == 0:    
   print("The factorial of 0 is 1")    
else:    
   for i in range(1,num + 1):    
       factorial = factorial*i    
   print("The factorial of",num,"is",factorial)    


# In[ ]:


#Q12Write a python program to find whether a number is prime or composite.


# In[2]:


num = int(input("Enter a number: "))  
  
if num > 1:  
   for i in range(2,num):  
       if (num % i) == 0:  
           print(num,"is not a prime number")  
           print(i,"times",num//i,"is",num)  
           break  
   else:  
       print(num,"is a prime number")  
         
else:  
   print(num,"is not a prime number")  


# In[ ]:


#Q13Write a python program to check whether a given string is palindrome or not


# In[4]:


my_str = 'malayalam'

my_str = my_str.casefold()

rev_str = reversed(my_str)

if list(my_str) == list(rev_str):
   print("The string is a palindrome.")
else:
   print("The string is not a palindrome.")


# In[ ]:


#Q14Write a Python program to get the third side of right-angled triangle from two given sides.


# In[7]:


def pythagoras(opposite_side,adjacent_side,hypotenuse):
        if opposite_side == str("x"):
            return ("Opposite = " + str(((hypotenuse**2) - (adjacent_side**2))**0.5))
        elif adjacent_side == str("x"):
            return ("Adjacent = " + str(((hypotenuse**2) - (opposite_side**2))**0.5))
        elif hypotenuse == str("x"):
            return ("Hypotenuse = " + str(((opposite_side**2) + (adjacent_side**2))**0.5))
        else:
            return "You know the answer!"
    
print(pythagoras(7,6,'x'))
print(pythagoras(3,'x',5))
print(pythagoras('x',4,5))
print(pythagoras(3,4,5))


# In[ ]:


#Q15Write a python program to print the frequency of each of the characters present in a given string


# In[8]:


string=input("Enter the string: ")
str1=list(string)
strlist=[]
for j in str1:
    if j not in strlist:
       strlist.append(j)
       count=0
       for i in range(len(str1)):
         if j==str1[i]:
           count+=1
       print("{},{}".format(j,count))


# In[ ]:




